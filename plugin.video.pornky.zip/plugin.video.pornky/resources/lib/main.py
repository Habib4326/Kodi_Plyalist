# -*- coding: utf-8 -*-
import sys
import urllib.parse
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from xml.etree import ElementTree as ET

# --- অ্যাডন সেটিংস ---
addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
addon_icon = addon.getAddonInfo('icon')
addon_fanart = addon.getAddonInfo('fanart')

# আপনার প্রধান বা রুট XML ফাইলের URL
# এই URL টি অ্যাডঅন প্রথমবার চালু হলে লোড হবে।
ROOT_XML_URL = "https://raw.githubusercontent.com/Habib4326/Kodi-Pornky/main/Main-Master.xml"
# --------------------

def log(msg, level=xbmc.LOGINFO):
    """Kodi লগে মেসেজ প্রিন্ট করার জন্য হেল্পার ফাংশন।"""
    xbmc.log(f"[{addon_id}] {msg}", level)

def get_xml_data(url):
    """প্রদত্ত URL থেকে XML ডেটা আনে।"""
    try:
        log(f"Fetching XML from: {url}")
        response = urllib.request.urlopen(url, timeout=15)
        xml_data = response.read()
        log("XML data fetched successfully.")
        return xml_data
    except Exception as e:
        log(f"Error fetching XML from {url}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Network Error", f"Failed to fetch data from the server.\n\nError: {e}")
        return None

def parse_and_display_items(xml_url):
    """
    XML ডেটা পার্স করে এবং Kodi-তে আইটেম (ফোল্ডার বা ভিডিও) প্রদর্শন করে।
    এটি যেকোনো XML ট্যাগ (item, movie, video, category ইত্যাদি) থেকে ডেটা পার্স করতে পারে।
    """
    xml_data = get_xml_data(xml_url)
    if not xml_data:
        xbmcplugin.endOfDirectory(addon_handle)
        return

    try:
        root = ET.fromstring(xml_data)
        
        # XML ফাইলের যেকোনো চাইল্ড ট্যাগকে আইটেম হিসেবে ধরে নেওয়া হবে।
        # যেমন: <categories><item>...</item></categories> বা <videos><movie>...</movie></videos>
        # findall('*') দিয়ে প্রথম স্তরের সব ট্যাগ পাওয়া যায়।
        items = root.findall('./*')
        if not items:
            log("No items found directly under the root. Searching for any item tags like 'item', 'movie', 'video', 'category'.")
            # যদি রুটের নিচে সরাসরি কোনো ট্যাগ না থাকে, তাহলে deeper search করা হবে।
            items = root.findall('.//item') + root.findall('.//movie') + root.findall('.//video') + root.findall('.//category')

        if not items:
            log("No parsable items found in the XML.", xbmc.LOGWARNING)
            xbmcgui.Dialog().ok("Empty List", "No items were found in the playlist.")
            xbmcplugin.endOfDirectory(addon_handle)
            return

        for item_node in items:
            # প্রতিটি আইটেম থেকে title, link, thumbnail, fanart খুঁজে বের করা
            title_node = item_node.find('title')
            link_node = item_node.find('link')
            thumb_node = item_node.find('thumbnail')
            fanart_node = item_node.find('fanart')

            # ডেটা presence check করা
            title = title_node.text.strip() if title_node is not None and title_node.text else "Untitled"
            link = link_node.text.strip() if link_node is not None and link_node.text else ""
            thumb = thumb_node.text.strip() if thumb_node is not None and thumb_node.text else addon_icon
            fanart = fanart_node.text.strip() if fanart_node is not None and fanart_node.text else addon_fanart
            
            if not link:
                log(f"Skipping item '{title}' due to missing link.", xbmc.LOGWARNING)
                continue

            #ListItem তৈরি করা
            list_item = xbmcgui.ListItem(label=title)
            
            # ফোল্ডার নাকি প্লে করার যোগ্য ভিডিও, তা নির্ধারণ করা
            # যদি লিঙ্কের শেষে .xml থাকে, তাহলে এটি একটি ফোল্ডার (ক্যাটাগরি)
            if link.lower().endswith('.xml'):
                is_folder = True
                # ফোল্ডারের জন্য URL তৈরি করা, যেখানে পরবর্তী XML ফাইলের লিঙ্ক থাকবে
                url = f"{base_url}?action=show_list&url={urllib.parse.quote_plus(link)}"
                list_item.setProperty('IsPlayable', 'false')
            else:
                is_folder = False
                # প্লে করার যোগ্য ভিডিওর জন্য URL হবে সরাসরি তার লিঙ্ক
                url = link
                list_item.setProperty('IsPlayable', 'true')
                list_item.setInfo('video', {'title': title, 'plot': title})

            # ছবি সেট করা
            list_item.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
            
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=is_folder)

        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log(f"Error parsing XML: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Parsing Error", f"An error occurred while parsing the XML file.\n\nError: {e}")
        xbmcplugin.endOfDirectory(addon_handle)

def get_params():
    """URL থেকে প্যারামিটার পার্স করে।"""
    param_string = sys.argv[2][1:]
    return dict(urllib.parse.parse_qsl(param_string))

def router():
    """মূল রাউটিং ফাংশন।"""
    params = get_params()
    action = params.get('action')

    if action == 'show_list':
        xml_url = params.get('url')
        if xml_url:
            parse_and_display_items(xml_url)
    else:
        # ডিফল্টরূপে, রুট XML ফাইলটি লোড করা
        parse_and_display_items(ROOT_XML_URL)

if __name__ == '__main__':
    router()
