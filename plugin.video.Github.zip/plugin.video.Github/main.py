# -*- coding: utf-8 -*-
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re

# --- Python 2/3 সামঞ্জস্য (Compatibility) ---
try:
    # Python 2 (Kodi 18 Leia এবং তার আগের ভার্সন)
    from urllib import quote_plus, unquote_plus
    from urllib2 import urlopen
    from urlparse import urlparse as parse_url 
except ImportError:
    # Python 3 (Kodi 19 Matrix এবং তার পরের ভার্সন)
    from urllib.parse import quote_plus, unquote_plus, urlparse as parse_url
    from urllib.request import urlopen

# --- গ্লোবাল সেটিংস ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# ফাইল সেভ করার জন্য Addon এর ডেটা পাথ (userdata/addon_data)
ADDON_DATA_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# নিশ্চিত করুন যে ডেটা ফোল্ডারটি আছে
if not xbmcvfs.exists(ADDON_DATA_PATH):
    xbmcvfs.mkdirs(ADDON_DATA_PATH)

xbmcplugin.setContent(HANDLE, 'movies')

# আপনার মাস্টার XML ফাইলের GitHub লিংক এখানে দিন
MASTER_XML_URL = "https://raw.githubusercontent.com/Habib4326/Kodi_Plyalist/refs/heads/main/Master.xml" # আপনার সঠিক লিংক ব্যবহার করুন

# --- ফাংশন ১: ইন্টারনেট থেকে কন্টেন্ট আনা ---
def fetch_url_content(url):
    try:
        response = urlopen(url)
        content = response.read()
        if sys.version_info.major >= 3 and isinstance(content, bytes):
             content = content.decode('utf-8')
        return content
    except Exception as e:
        xbmc.log("Failed to fetch URL: %s Error: %s" % (url, str(e)), xbmc.LOGERROR)
        return None

# --- ফাংশন ২: ডাউনলোড এবং লোকাল সেভ (বড় XML ফাইলগুলোর জন্য) ---
def download_and_save(url, local_path):
    content = fetch_url_content(url)
    if content:
        try:
            f = xbmcvfs.File(local_path, 'w')
            f.write(content)
            f.close()
            return True
        except Exception as e:
            xbmc.log("Failed to save local file: %s" % str(e), xbmc.LOGERROR)
            return False
    return False

# --- ফাংশন ৩: লোকাল ফাইল পড়া ---
def read_local_file(path):
    try:
        f = xbmcvfs.File(path)
        content = f.read()
        f.close()
        return content
    except Exception as e:
        return None

# --- ফাংশন ৪: লিস্ট আইটেম যোগ করা ---
def add_list_item(name, url, mode, is_folder, icon='Default.png', fanart=None, year=None):
    
    if is_folder:
        action_url = BASE_URL + '?mode=' + str(mode) + '&url=' + quote_plus(url)
    else:
        action_url = url

    list_item = xbmcgui.ListItem(label=name)
    
    # আর্টওয়ার্ক সেট করা (এখানে Fanart সাপোর্ট আছে)
    art = {'icon': icon, 'thumb': icon}
    if fanart:
        art['fanart'] = fanart
    list_item.setArt(art)

    # তথ্য সেট করা
    info_labels = {'Title': name}
    if year and year.isdigit():
        info_labels['Year'] = int(year)
    list_item.setInfo(type='Video', infoLabels=info_labels)
    
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')

    xbmcplugin.addDirectoryItem(handle=HANDLE, url=action_url, listitem=list_item, isFolder=is_folder)

# --- ফাংশন ৫: মাস্টার XML পার্স করা (প্রধান মেনু) - আপডেটেড ---
def main_menu(master_url):
    content = fetch_url_content(master_url)
    if not content:
        xbmcgui.Dialog().notification('Error', 'Failed to load Master XML.', xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False) 
        return

    # <category> ট্যাগ খোঁজা
    categories = re.compile('<category>(.*?)</category>', re.DOTALL).findall(content)
    for cat in categories:
        title_match = re.search('<title>(.*?)</title>', cat, re.IGNORECASE)
        link_match = re.search('<link>(.*?)</link>', cat, re.IGNORECASE)
        thumb_match = re.search('<thumbnail>(.*?)</thumbnail>', cat, re.IGNORECASE)
        # নতুন: ক্যাটাগরির জন্য <fanart> খোঁজা
        fanart_match = re.search('<fanart>(.*?)</fanart>', cat, re.IGNORECASE)

        if title_match and link_match:
            title = title_match.group(1)
            remote_link = link_match.group(1)
            thumb = thumb_match.group(1) if thumb_match else 'DefaultFolder.png'
            # নতুন: fanart ভ্যারিয়েবল সেট করা
            fanart = fanart_match.group(1) if fanart_match else None
            
            # নতুন: add_list_item এ fanart পাস করা
            add_list_item(title, remote_link, mode=1, is_folder=True, icon=thumb, fanart=fanart)

    xbmcplugin.endOfDirectory(HANDLE)

# --- ফাংশন ৬: ক্যাটাগরি প্রসেস করা (ডাউনলোড -> লোকাল রিড -> পার্সিং) ---
def process_category(remote_url):
    
    # রিমোট URL থেকে ফাইলের নাম বের করা
    parsed_url = parse_url(remote_url)
    filename = os.path.basename(parsed_url.path)

    if not filename:
        filename = "temp_playlist.xml"

    # লোকাল ফাইলের সম্পূর্ণ পাথ তৈরি করা (userdata ফোল্ডারে)
    local_path = os.path.join(ADDON_DATA_PATH, filename)

    # ১. ডাউনলোড এবং সেভ
    dialog = xbmcgui.DialogProgress()
    dialog.create("Updating", "Downloading playlist: %s" % filename)
    
    is_downloaded = download_and_save(remote_url, local_path)
    dialog.close()

    if not is_downloaded:
        xbmcgui.Dialog().notification('Update Failed', 'Using local cached file.', xbmcgui.NOTIFICATION_WARNING, 3000)

    # ২. লোকাল ফাইল থেকে পড়া
    content = read_local_file(local_path)
    
    if not content:
        xbmcgui.Dialog().ok('Error', 'Failed to download and no local cache found.')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # ৩. মুভি পার্সিং
    movies = re.compile('<movie>(.*?)</movie>', re.DOTALL).findall(content)
    for movie in movies:
        title_match = re.search('<title>(.*?)</title>', movie, re.IGNORECASE)
        link_match = re.search('<link>(.*?)</link>', movie, re.IGNORECASE)
        thumb_match = re.search('<thumbnail>(.*?)</thumbnail>', movie, re.IGNORECASE)
        fanart_match = re.search('<fanart>(.*?)</fanart>', movie, re.IGNORECASE)
        year_match = re.search('<year>(.*?)</year>', movie, re.IGNORECASE)

        if title_match and link_match:
            title = title_match.group(1)
            link = link_match.group(1)
            thumb = thumb_match.group(1) if thumb_match else 'DefaultVideo.png'
            fanart = fanart_match.group(1) if fanart_match else None
            year = year_match.group(1) if year_match else None
            
            add_list_item(title, link, mode=0, is_folder=False, icon=thumb, fanart=fanart, year=year)

    xbmcplugin.endOfDirectory(HANDLE)

# --- ফাংশন ৭: URL প্যারামিটার পড়া (রাউটিং) ---
def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if cleanedparams.endswith('/'):
             cleanedparams = cleanedparams[:-1]

        pairsofparams = cleanedparams.split('&')
        for i in range(len(pairsofparams)):
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = unquote_plus(splitparams[1])
    return param

# --- প্রধান রাউটিং লজিক ---
params = get_params()
mode = params.get('mode')
url = params.get('url')

try:
    mode = int(mode)
except:
    mode = None

if mode == 1:
    process_category(url)
elif mode == 0:
    pass
else:
    main_menu(MASTER_XML_URL)