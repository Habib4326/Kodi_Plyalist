# -*- coding: utf-8 -*-
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import xbmcplugin
import xbmcgui
import xbmcaddon

# Kodi অ্যাড-অনের তথ্য লোড করুন
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')

# অ্যাড-অনের ডিফল্ট আইকন এবং ফ্যানার্ট (যদি XML-এ না থাকে তবে এগুলো ব্যবহৃত হবে)
ADDON_ICON = addon.getAddonInfo('icon')
ADDON_FANART = addon.getAddonInfo('fanart')

# --- আপনার XML ফাইলগুলির তালিকা/ডিকশনারি এখানে যুক্ত করুন ---
# প্রতিটি কী হবে মেনুতে প্রদর্শিত ক্যাটাগরির নাম।
# ভ্যালু হবে একটি ডিকশনারি যাতে 'url' এবং ঐচ্ছিকভাবে 'thumb' ও 'fanart' থাকবে।
XML_SOURCES = {
    "English Movies": {
        "url": "https://raw.githubusercontent.com/Habib4326/Kodi_Plyalist/refs/heads/main/Main-Directory/English-Movies.xml",
          # এখানে আপনার কাস্টম থাম্বনেইল লিংক দিন
        "fanart": "https://i.ibb.co/N6JbhwM5/wp6577360-the-maze-runner-poster-desktop-wallpapers.jpg"   # এখানে আপনার কাস্টম ফ্যানার্ট লিংক দিন
    },
    "Hindi Movies": {
        "url": "https://raw.githubusercontent.com/Habib4326/Kodi_Plyalist/refs/heads/main/Main-Directory/Hindi-Movies.xml",
        
        "fanart": "https://i.ibb.co/MypJG7K7/wp14648060-bhool-bhulaiyaa-3-wallpapers.jpg"
    },
    "Dubbed Movies": {
        "url": "https://raw.githubusercontent.com/Habib4326/Kodi_Plyalist/refs/heads/main/Main-Directory/Dubbed-Movies.xml",
        
        "fanart": "https://i.ibb.co/Rpck3J7d/wp8176175-raaz-reboot-wallpapers.jpg"
    },
    "adults videos": {
        "url": "https://raw.githubusercontent.com/Habib4326/Kodi_Plyalist/refs/heads/main/Main-Directory/adults%20-videos.xml",
        
        "fanart": "https://i.ibb.co/ZRWNz5Qr/OUVFEP0.jpg"
    },
    # আপনার প্রয়োজন অনুযায়ী আরও ক্যাটাগরি এবং XML ফাইল যোগ করুন
}
# --- XML ফাইলগুলির তালিকা/ডিকশনারি শেষ ---

def fetch_movies(xml_url):
    """নির্দিষ্ট XML ফাইল URL থেকে ডেটা ডাউনলোড করে পার্স করে।"""
    print(f"DEBUG: XML ডেটা আনার চেষ্টা করা হচ্ছে: {xml_url}")
    try:
        with urllib.request.urlopen(xml_url, timeout=15) as response: # টাইমআউট 15 সেকেন্ডে বাড়ানো হয়েছে
            xml_data = response.read()
        print("DEBUG: XML ডেটা সফলভাবে আনা হয়েছে।")
        root = ET.fromstring(xml_data)
        return root.findall('movie')
    except urllib.error.URLError as e:
        error_message = f"XML ফাইল ডাউনলোড করতে সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Popcorn Movie Stream", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []
    except ET.ParseError as e:
        error_message = f"XML পার্স করতে সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Popcorn Movie Stream", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []
    except Exception as e:
        error_message = f"একটি অজানা সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Popcorn Movie Stream", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []

def build_menu():
    """প্রধান মেনু তৈরি করে (যেমন: All Movies, English Movies ইত্যাদি)।"""
    print("DEBUG: প্রধান মেনু তৈরি করা হচ্ছে।")

    # XML_SOURCES ডিকশনারি থেকে ক্যাটাগরিগুলি যোগ করুন
    for category_name, category_data in XML_SOURCES.items():
        list_item = xbmcgui.ListItem(label=category_name)
        
        # ক্যাটাগরি আইটেমের জন্য থাম্বনেইল এবং ফ্যানার্ট সেট করুন
        # যদি নির্দিষ্ট ক্যাটাগরির জন্য কাস্টম থাম্ব/ফ্যানার্ট থাকে, তবে সেটি ব্যবহার করুন।
        # অন্যথায়, অ্যাড-অনের ডিফল্ট আইকন/ফ্যানার্ট ব্যবহার করুন।
        list_item.setArt({
            'thumb': category_data.get('thumb', ADDON_ICON),
            'fanart': category_data.get('fanart', ADDON_FANART),
            'icon': category_data.get('thumb', ADDON_ICON) # 'icon' সাধারণত 'thumb' এর মতো হয়
        })

        # URL তৈরি করুন যেখানে 'action=list_movies' এবং 'xml_url' প্যারামিটার থাকবে
        url = sys.argv[0] + f"?action=list_movies&xml_url={urllib.parse.quote_plus(category_data['url'])}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        print(f"DEBUG: '{category_name}' ক্যাটাগরি আইটেম যোগ করা হয়েছে। URL: {url}")

    xbmcplugin.endOfDirectory(addon_handle)
    print("DEBUG: প্রধান মেনু তৈরি সম্পন্ন হয়েছে।")

def list_movies(xml_url):
    """নির্দিষ্ট XML ফাইল থেকে মুভি লোড করে Kodi-এর ইন্টারফেসে দেখায়।
    এই ফাংশনটি এখন কোনো জেনরা ফিল্টারিং করে না, এটি শুধুমাত্র প্রাপ্ত XML থেকে মুভি প্রদর্শন করে।"""
    print(f"DEBUG: মুভি তালিকা তৈরি করা হচ্ছে। XML URL: {xml_url}")
    movies = fetch_movies(xml_url)

    if not movies:
        xbmcgui.Dialog().notification("Popcorn Movie Stream", "এই ক্যাটাগরিতে কোন মুভি পাওয়া যায়নি।", xbmcgui.NOTIFICATION_INFO)
        print("DEBUG: কোন মুভি পাওয়া যায়নি বা ফিল্টারে কোন মুভি মেলেনি।")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for movie in movies:
        # XML থেকে মুভির তথ্য নিন, যদি না থাকে তবে ডিফল্ট মান ব্যবহার করুন
        title = movie.find('title').text if movie.find('title') is not None else 'Unknown Title'
        url = movie.find('link').text if movie.find('link') is not None else ''
        
        # আর্টওয়ার্ক ট্যাগগুলি থেকে লিংক নিন, যদি না থাকে তবে ডিফল্ট বা ফলব্যাক ব্যবহার করুন
        thumb = movie.find('thumbnail').text if movie.find('thumbnail') is not None else ADDON_ICON
        poster = movie.find('poster').text if movie.find('poster') is not None else thumb
        fanart = movie.find('fanart').text if movie.find('fanart') is not None else ADDON_FANART
        banner = movie.find('banner').text if movie.find('banner') is not None else poster
        clearart = movie.find('clearart').text if movie.find('clearart') is not None else fanart

        year = movie.find('year').text if movie.find('year') is not None else ''
        genre = movie.find('genre').text if movie.find('genre') is not None else ''
        plot = movie.find('plot').text if movie.find('plot') is not None else ''

        list_item = xbmcgui.ListItem(label=title)
        
        # Kodi এর জন্য আর্টওয়ার্ক সেট করুন
        list_item.setArt({
            'thumb': thumb,
            'poster': poster,
            'fanart': fanart,
            'clearart': clearart,
            'banner': banner,
            'icon': thumb # 'icon' সাধারণত 'thumb' এর মতো হয়
        })

        # ভিডিও তথ্য সেট করুন (Kodi এর ইনফো স্ক্রিন দেখানোর জন্য)
        list_item.setInfo('video', {'title': title, 'year': int(year) if year.isdigit() else 0, 'genre': genre, 'plot': plot})
        list_item.setProperty('IsPlayable', 'true') # এটি একটি প্লেয়েবল আইটেম তা নির্দেশ করে
        
        print(f"DEBUG: মুভি যোগ করা হচ্ছে: {title}, লিংক: {url}, থাম্ব: {thumb}, পোস্টার: {poster}, ফ্যানার্ট: {fanart}")

        # Kodi ডিরেক্টরিতে আইটেমটি যোগ করুন
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)
    print(f"DEBUG: মোট {len(movies)} টি মুভি তালিকাভুক্ত করা হয়েছে।")

def router(paramstring):
    """URL প্যারামিটার হ্যান্ডেল করে এবং সঠিক ফাংশন কল করে।"""
    print(f"DEBUG: রাউটার শুরু হয়েছে। প্যারামিটার: {paramstring}")
    params = dict(urllib.parse.parse_qsl(paramstring)) # প্যারামিটার পার্স করুন
    action = params.get('action') # 'action' প্যারামিটারটি নিন

    if action == 'list_movies':
        # যদি অ্যাকশন 'list_movies' হয়, তাহলে 'xml_url' প্যারামিটারটি নিন
        xml_url = params.get('xml_url')
        if xml_url:
            list_movies(xml_url=xml_url) # নির্দিষ্ট XML URL থেকে মুভি তালিকা লোড করুন
        else:
            # যদি xml_url না থাকে, একটি ত্রুটি বার্তা দেখান
            xbmcgui.Dialog().notification("Popcorn Movie Stream", "কোন XML URL নির্দিষ্ট করা হয়নি।", xbmcgui.NOTIFICATION_ERROR)
            print("ERROR: 'list_movies' অ্যাকশনের জন্য কোন XML URL নির্দিষ্ট করা হয়নি।")
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    else:
        # যদি কোন অ্যাকশন নির্দিষ্ট না থাকে বা অজানা অ্যাকশন হয়, তাহলে প্রধান মেনু তৈরি করুন
        build_menu()

if __name__ == '__main__':
    # স্ক্রিপ্টটি যখন শুরু হয়, তখন router ফাংশন কল করুন
    router(sys.argv[2][1:])