# -*- coding: utf-8 -*-
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import xbmcplugin
import xbmcgui
import xbmcaddon

# Kodi অ্যাড-অনের তথ্য লোড করুন
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')

# --- সেটিংস থেকে URL পড়ুন ---
# settings.xml ফাইলে আমরা 'master_xml_url' আইডি দিয়েছি
MAIN_XML_URL = addon.getSetting('master_xml_url') 

# যদি ব্যবহারকারী সেটিংস থেকে URL মুছে ফেলে বা সেট না করে, তবে একটি ডিফল্ট URL ব্যবহার করুন
if not MAIN_XML_URL:
     MAIN_XML_URL = "https://raw.githubusercontent.com/Habib4326/Kodi_Plyalist/refs/heads/main/Master.xml" # আপনার ডিফল্ট URL

# অ্যাড-অনের ডিফল্ট আইকন এবং ফ্যানার্ট (যদি XML-এ না থাকে তবে এগুলো ব্যবহৃত হবে)
ADDON_ICON = addon.getAddonInfo('icon')
ADDON_FANART = addon.getAddonInfo('fanart')
# --- সেটিংস পড়া শেষ ---

def fetch_movies(xml_url):
    """নির্দিষ্ট XML ফাইল URL থেকে ডেটা ডাউনলোড করে পার্স করে এবং মুভিগুলির তালিকা প্রদান করে।"""
    print(f"DEBUG: XML ডেটা আনার চেষ্টা করা হচ্ছে: {xml_url}")
    try:
        # কিছু সার্ভার User-Agent ছাড়া রিকোয়েস্ট ব্লক করতে পারে।
        headers = {'User-Agent': 'Kodi/1.0'}
        req = urllib.request.Request(xml_url, headers=headers)
        with urllib.request.urlopen(req, timeout=15) as response: # টাইমআউট 15 সেকেন্ডে বাড়ানো হয়েছে
            xml_data = response.read()
            # ডেটা UTF-8 এনকোডিং-এ আছে কিনা তা নিশ্চিত করুন, অথবা প্রয়োজন অনুযায়ী ডিকোড করুন।
            # xml_data = xml_data.decode('utf-8', errors='ignore') 
        print(f"DEBUG: XML ডেটা সফলভাবে আনা হয়েছে (URL: {xml_url}), সাইজ: {len(xml_data)} বাইট।")
        root = ET.fromstring(xml_data)
        
        # আপনার Master.xml ফাইলে ক্যাটাগরির নিচে movie ট্যাগ আছে, 
        # কিন্তু যদি ক্যাটাগরির ভেতরের ফাইলে শুধু movie ট্যাগ থাকে তাহলে এই ফাইন্ড কাজ করবে।
        # যদি কোনো ক্যাটাগরির XML ফাইলে movie এর বদলে item ট্যাগ থাকে, তাহলে সেটাকেও হ্যান্ডেল করতে হবে।
        movies = root.findall('movie') # যদি মূল XML শুধু movie ট্যাগ ব্যবহার করে
        if not movies:
             movies = root.findall('item') # কিছু XML এ 'item' ব্যবহার হতে পারে
        
        if not movies:
             print(f"DEBUG: '{xml_url}' এ কোনো 'movie' বা 'item' ট্যাগ পাওয়া যায়নি।")
        return movies
        
    except urllib.error.URLError as e:
        error_message = f"XML ফাইল ডাউনলোড করতে সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Movie Club", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []
    except ET.ParseError as e:
        error_message = f"XML পার্স করতে সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Movie Club", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []
    except Exception as e:
        error_message = f"একটি অজানা সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Movie Club", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []

def fetch_categories(xml_url):
    """প্রধান XML ফাইল থেকে ক্যাটাগরিগুলির তালিকা পার্স করে।"""
    print(f"DEBUG: প্রধান XML থেকে ক্যাটাগরি আনার চেষ্টা করা হচ্ছে: {xml_url}")
    try:
        headers = {'User-Agent': 'Kodi/1.0'}
        req = urllib.request.Request(xml_url, headers=headers)
        with urllib.request.urlopen(req, timeout=15) as response:
            xml_data = response.read()
            # xml_data = xml_data.decode('utf-8', errors='ignore') # প্রয়োজন অনুযায়ী ডিকোড করুন
        print(f"DEBUG: প্রধান XML ডেটা সফলভাবে আনা হয়েছে (URL: {xml_url}), সাইজ: {len(xml_data)} বাইট।")
        root = ET.fromstring(xml_data)
        categories = root.findall('category') # Master.xml এ category ট্যাগ ব্যবহার করা হয়েছে
        if not categories:
             print(f"DEBUG: '{xml_url}' এ কোনো 'category' ট্যাগ পাওয়া যায়নি।")
        return categories
    except urllib.error.URLError as e:
        error_message = f"প্রধান XML ফাইল ডাউনলোড করতে সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Movie Club", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []
    except ET.ParseError as e:
        error_message = f"প্রধান XML পার্স করতে সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Movie Club", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []
    except Exception as e:
        error_message = f"প্রধান XML হ্যান্ডেল করতে একটি অজানা সমস্যা: {str(e)}. URL: {xml_url}"
        print(f"ERROR: {error_message}")
        xbmcgui.Dialog().notification("Movie Club", error_message, xbmcgui.NOTIFICATION_ERROR)
        return []

def build_menu():
    """প্রধান মেনু তৈরি করে (যেমন: All Movies, English Movies ইত্যাদি)।"""
    print("DEBUG: প্রধান মেনু তৈরি করা হচ্ছে।")
    
    # সেটিংস থেকে প্রাপ্ত MAIN_XML_URL ব্যবহার করে ক্যাটাগরি লোড করা হচ্ছে
    categories = fetch_categories(MAIN_XML_URL)
    
    if not categories:
        xbmcgui.Dialog().notification("Movie Club", "কোন ক্যাটাগরি পাওয়া যায়নি। অনুগ্রহ করে অ্যাড-অনের সেটিংসে Master XML URL চেক করুন।", xbmcgui.NOTIFICATION_WARNING)
        print("ERROR: প্রধান মেনু তৈরি করা যায়নি কারণ কোনো ক্যাটাগরি পাওয়া যায়নি।")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    # XML_SOURCES ডিকশনারি এখন আর ব্যবহার হচ্ছে না, পরিবর্তে MAIN_XML_URL থেকে ক্যাটাগরি লোড হচ্ছে।
    for category in categories:
        # আপনার Master.xml ফাইলে ক্যাটাগরির মধ্যে 'title' ট্যাগ আছে
        category_name = category.find('title').text if category.find('title') is not None else "Untitled Category"
        # আপনার Master.xml ফাইলে ক্যাটাগরির মধ্যে 'link' ট্যাগ আছে যা পরবর্তী XML ফাইলের URL ধারণ করে
        category_link_url = category.find('link').text if category.find('link') is not None else None
        category_thumb = category.find('thumb').text if category.find('thumb') is not None else ADDON_ICON
        category_fanart = category.find('fanart').text if category.find('fanart') is not None else ADDON_FANART
        
        if not category_link_url:
            print(f"WARNING: '{category_name}' ক্যাটাগরির জন্য কোনো লিঙ্ক পাওয়া যায়নি, এটি এড়িয়ে যাওয়া হচ্ছে।")
            continue

        list_item = xbmcgui.ListItem(label=category_name)
        
        # ক্যাটাগরি আইটেমের জন্য থাম্বনেইল এবং ফ্যানার্ট সেট করুন
        list_item.setArt({
            'thumb': category_thumb,
            'fanart': category_fanart,
            'icon': category_thumb # 'icon' সাধারণত 'thumb' এর মতো হয়
        })

        # URL তৈরি করুন যেখানে 'action=list_items' এবং 'category_url' প্যারামিটার থাকবে
        # category_link_url কে URL-encode করা হচ্ছে যাতে বিশেষ অক্ষর সমস্যা না করে।
        encoded_category_url = urllib.parse.quote_plus(category_link_url)
        url = sys.argv[0] + f"?action=list_items&category_url={encoded_category_url}"
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        print(f"DEBUG: '{category_name}' ক্যাটাগরি আইটেম যোগ করা হয়েছে। URL: {url}")

    xbmcplugin.endOfDirectory(addon_handle)
    print("DEBUG: প্রধান মেনু তৈরি সম্পন্ন হয়েছে।")

def list_items(category_url):
    """নির্দিষ্ট XML ফাইল থেকে আইটেম (যেমন মুভি) লোড করে Kodi-এর ইন্টারফেসে দেখায়।"""
    print(f"DEBUG: আইটেম তালিকা তৈরি করা হচ্ছে। ক্যাটাগরি URL: {category_url}")
    
    # fetch_movies ফাংশন এখন movie বা item ট্যাগ খুঁজে বের করার চেষ্টা করবে।
    items = fetch_movies(category_url) 

    if not items:
        xbmcgui.Dialog().notification("Movie Club", "এই ক্যাটাগরিতে কোনো আইটেম পাওয়া যায়নি। অনুগ্রহ করে লিঙ্কটি চেক করুন।", xbmcgui.NOTIFICATION_INFO)
        print(f"DEBUG: '{category_url}' থেকে কোনো আইটেম পাওয়া যায়নি।")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for item in items:
        # এখানে আপনার XML-এর গঠন অনুযায়ী ডেটা পার্স করতে হবে।
        # সাধারণত '<movie>' ট্যাগের মধ্যে <title>, <link>, <thumbnail>, <poster>, <fanart>, <year>, <genre>, <plot> থাকে।
        # যদি আপনার XML অন্য ট্যাগ ব্যবহার করে, তবে এখানে সেই অনুযায়ী পরিবর্তন করুন।
        
        # কিছু সাধারণ ট্যাগ ব্যবহার করার চেষ্টা করা হচ্ছে:
        title = item.find('title').text if item.find('title') is not None else 'Unknown Title'
        item_url = item.find('link').text if item.find('link') is not None else None # এটি প্লে করার URL
        
        # আর্টওয়ার্ক ট্যাগগুলি থেকে লিংক নিন, যদি না থাকে তবে ডিফল্ট বা ফলব্যাক ব্যবহার করুন
        thumb = item.find('thumbnail').text if item.find('thumbnail') is not None else (ADDON_ICON if ADDON_ICON else '')
        poster = item.find('poster').text if item.find('poster') is not None else thumb
        fanart = item.find('fanart').text if item.find('fanart') is not None else (ADDON_FANART if ADDON_FANART else '')
        banner = item.find('banner').text if item.find('banner') is not None else poster # অনেক সময় banner থাকে না
        clearart = item.find('clearart').text if item.find('clearart') is not None else fanart # অনেক সময় clearart থাকে না

        year_str = item.find('year').text if item.find('year') is not None else ''
        genre_str = item.find('genre').text if item.find('genre') is not None else ''
        plot = item.find('plot').text if item.find('plot') is not None else ''

        if not item_url: # যদি প্লে করার URL না থাকে তবে এই আইটেমটি এড়িয়ে যান
            print(f"WARNING: '{title}' এর জন্য কোনো প্লে লিঙ্ক পাওয়া যায়নি, এড়িয়ে যাওয়া হচ্ছে।")
            continue
            
        # Kodi এর জন্য আর্টওয়ার্ক সেট করুন
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({
            'thumb': thumb,
            'poster': poster,
            'fanart': fanart,
            'clearart': clearart,
            'banner': banner,
            'icon': thumb # 'icon' সাধারণত 'thumb' এর মতো হয়
        })

        # ভিডিও তথ্য সেট করুন (Kodi এর ইনফো স্ক্রিন দেখানোর জন্য)
        try:
            year = int(year_str) if year_str and year_str.isdigit() else 0
        except ValueError:
            year = 0
            
        list_item.setInfo('video', {
            'title': title, 
            'year': year, 
            'genre': genre_str, 
            'plot': plot,
            # এখানে আপনি আরও তথ্য যোগ করতে পারেন যেমন 'rating', 'director', 'cast' ইত্যাদি যদি আপনার XML-এ থাকে।
        })
        list_item.setProperty('IsPlayable', 'true') # এটি একটি প্লেয়েবল আইটেম তা নির্দেশ করে
        
        print(f"DEBUG: আইটেম যোগ করা হচ্ছে: {title}, URL: {item_url}, থাম্ব: {thumb}, পোস্টার: {poster}, ফ্যানার্ট: {fanart}")

        # Kodi ডিরেক্টরিতে আইটেমটি যোগ করুন
        # item_url হল আসল ভিডিও ফাইলের URL যা প্লে করা হবে।
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)
    print(f"DEBUG: মোট {len(items)} টি আইটেম তালিকাভুক্ত করা হয়েছে।")

def router(paramstring):
    """URL প্যারামিটার হ্যান্ডেল করে এবং সঠিক ফাংশন কল করে।"""
    print(f"DEBUG: রাউটার শুরু হয়েছে। প্যারামিটার স্ট্রিং: {paramstring}")
    params = dict(urllib.parse.parse_qsl(paramstring)) # প্যারামিটার পার্স করুন
    action = params.get('action') # 'action' প্যারামিটারটি নিন

    if action == 'list_items':
        # যদি অ্যাকশন 'list_items' হয়, তাহলে 'category_url' প্যারামিটারটি নিন
        category_url = params.get('category_url')
        if category_url:
            list_items(category_url=category_url) # নির্দিষ্ট URL থেকে আইটেম তালিকা লোড করুন
        else:
            # যদি category_url না থাকে, একটি ত্রুটি বার্তা দেখান
            xbmcgui.Dialog().notification("Movie Club", "কোন ক্যাটাগরি URL নির্দিষ্ট করা হয়নি।", xbmcgui.NOTIFICATION_ERROR)
            print("ERROR: 'list_items' অ্যাকশনের জন্য কোনো 'category_url' নির্দিষ্ট করা হয়নি।")
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    else:
        # যদি কোন অ্যাকশন নির্দিষ্ট না থাকে বা এটি প্রধান মেনু লোড করার জন্য হয়, তাহলে প্রধান মেনু তৈরি করুন
        build_menu()

if __name__ == '__main__':
    # স্ক্রিপ্টটি যখন শুরু হয়, তখন router ফাংশন কল করুন।
    # sys.argv[2] হল URL এর অংশ যা কোয়েরি স্ট্রিং ধারণ করে, যেমন "?action=..."
    # sys.argv[2][1:] মানে স্ট্রিং এর প্রথম অক্ষর (সাধারণত '?') বাদ দেওয়া।
    if len(sys.argv) >= 3 and sys.argv[2].startswith('?'):
        router(sys.argv[2][1:])
    else:
        # যদি কোনো প্যারামিটার না থাকে, তাহলে প্রধান মেনু লোড করুন
        build_menu()